<template>
    <routerView></routerView>
</template>

<script setup>

</script>

<style scoped>

</style>